package com.example.aimext

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import java.util.Arrays
import kotlin.math.*

data class Vec(val x: Double, val y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun len() = hypot(x, y)
    fun norm(): Vec { val l = len(); return if (l < 1e-9) Vec(0.0, 0.0) else Vec(x / l, y / l) }
}

/** A filc (a golyó-középpont számára elérhető terület pereme + r adódik hozzá a Trajectory-ban): a posztó és a szalag találkozása. */
data class Table(val left: Double, val top: Double, val right: Double, val bottom: Double)

/**
 * Minden koordináta teljes felbontású képernyő-pixel.
 * ghost  = a játék saját "szellemgyűrűje" (ahol a fehér golyó először ütközik)
 * target = az eltalált golyó közepe. Ha mindkettő megvan, pontosan a játék saját fizikáját folytatjuk.
 */
data class Scene(
    val cue: Vec, val dir: Vec, val balls: List<Vec>, val table: Table, val r: Double,
    val ghost: Vec? = null, val target: Vec? = null
)

object Detector {
    @Volatile var status = ""

    /** Golyósugár / az asztal rövidebbik oldala (a zöld folt befoglalója, szalaggal együtt). Minden képernyőmérethez igazodik. */
    const val TABLE_R_FRAC = 0.0285
    /** A szalag (sötétzöld csík) vastagsága / asztal rövidebbik oldala: a golyó a posztó szélén pattan. */
    const val CUSHION_FRAC = 0.0215
    /** Ekkora golyósugárra (pixel) skálázzuk a képet a feldolgozáshoz, függetlenül a képernyő méretétől és képarányától. */
    private const val TARGET_R = 14.0

    /** A saját rárajzolásunk színei: ezeket a felismerés előtt kiretusáljuk, így nem látja a saját vonalainkat. */
    private val OVL = arrayOf(doubleArrayOf(0.0, 255.0, 255.0), doubleArrayOf(255.0, 0.0, 255.0))

    private class Circ(val x: Double, val y: Double, val empty: Boolean, val white: Boolean)

    private class Img(val cols: Int, val rows: Int, val data: ByteArray) {
        fun on(x: Int, y: Int): Boolean = x >= 0 && y >= 0 && x < cols && y < rows && data[y * cols + x].toInt() != 0
    }

    private fun bytes(m: Mat): ByteArray { val b = ByteArray(m.rows() * m.cols()); m.get(0, 0, b); return b }

    fun detect(bmp: Bitmap): Scene? {
        val mats = ArrayList<Mat>()
        fun m() = Mat().also { mats.add(it) }
        try {
            val full = m()
            Utils.bitmapToMat(bmp, full)

            // A) durva asztalkeresés bélyegképen -> ebből jön a munkaskála (a golyósugár ~TARGET_R pixel lesz)
            val s0 = min(1.0, 480.0 / max(bmp.width, bmp.height))
            val th = m(); Imgproc.resize(full, th, Size(), s0, s0, Imgproc.INTER_AREA)
            val th3 = m(); Imgproc.cvtColor(th, th3, Imgproc.COLOR_RGBA2RGB)
            val thHsv = m(); Imgproc.cvtColor(th3, thHsv, Imgproc.COLOR_RGB2HSV)
            val g0 = m(); Core.inRange(thHsv, Scalar(35.0, 60.0, 60.0), Scalar(90.0, 255.0, 255.0), g0)
            val gc0 = ArrayList<MatOfPoint>()
            Imgproc.findContours(g0, gc0, m(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val big0 = gc0.maxByOrNull { Imgproc.contourArea(it) } ?: run { status = "asztal nincs"; return null }
            val bb = Imgproc.boundingRect(big0)
            if (min(bb.width, bb.height) < 0.25 * min(th.cols(), th.rows())) { status = "asztal tul kicsi"; return null }
            val s = (TARGET_R / (min(bb.width, bb.height) / s0 * TABLE_R_FRAC)).coerceIn(0.2, 2.0)

            // B) munkakép
            val small = m()
            Imgproc.resize(full, small, Size(), s, s, if (s < 1.0) Imgproc.INTER_AREA else Imgproc.INTER_LINEAR)
            val rgb0 = m(); Imgproc.cvtColor(small, rgb0, Imgproc.COLOR_RGBA2RGB)
            val cols = rgb0.cols(); val rows = rgb0.rows()

            // 0) a saját rárajzolás kiretusálása (különben visszacsatolás: a felismerő a saját vonalunkat látná)
            val ov = Mat.zeros(rows, cols, CvType.CV_8UC1); mats.add(ov)
            for (c in OVL) {
                val t = m()
                Core.inRange(
                    rgb0,
                    Scalar(max(0.0, c[0] - 55), max(0.0, c[1] - 55), max(0.0, c[2] - 55)),
                    Scalar(min(255.0, c[0] + 55), min(255.0, c[1] + 55), min(255.0, c[2] + 55)), t
                )
                Core.bitwise_or(ov, t, ov)
            }
            val k5 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0)); mats.add(k5)
            Imgproc.dilate(ov, ov, k5)
            val rgb = m()
            if (Core.countNonZero(ov) > 0) Photo.inpaint(rgb0, ov, rgb, 3.0, Photo.INPAINT_TELEA) else rgb0.copyTo(rgb)
            val rgbA = ByteArray(cols * rows * 3); rgb.get(0, 0, rgbA)

            // 1) asztal = legnagyobb zöld folt
            val hsv = m(); Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
            val green = m(); Core.inRange(hsv, Scalar(35.0, 60.0, 60.0), Scalar(90.0, 255.0, 255.0), green)
            val gc = ArrayList<MatOfPoint>()
            Imgproc.findContours(green, gc, m(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val big = gc.maxByOrNull { Imgproc.contourArea(it) } ?: run { status = "asztal nincs"; return null }
            val tb = Imgproc.boundingRect(big)
            val tShort = min(tb.width, tb.height).toDouble()
            val r = tShort * TABLE_R_FRAC
            val inset = tShort * CUSHION_FRAC
            val felt = medianRect(
                rgbA, cols,
                tb.x + (tb.width * 0.2).toInt(), tb.y + (tb.height * 0.2).toInt(),
                tb.x + (tb.width * 0.8).toInt(), tb.y + (tb.height * 0.8).toInt()
            )

            // maszkok
            val whiteM = m(); Core.inRange(rgb, Scalar(205.0, 205.0, 205.0), Scalar(255.0, 255.0, 255.0), whiteM)
            val k3 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)); mats.add(k3)
            Imgproc.dilate(whiteM, whiteM, k3)
            Core.bitwise_or(whiteM, ov, whiteM)           // ahol a saját vonalunk keresztezi, ott is "rendben"
            val lineOk = Img(cols, rows, bytes(whiteM))
            val brightM = m(); Core.inRange(rgb, Scalar(185.0, 185.0, 185.0), Scalar(255.0, 255.0, 255.0), brightM)
            val bright = Img(cols, rows, bytes(brightM))
            val gray0 = m(); Imgproc.cvtColor(rgb, gray0, Imgproc.COLOR_RGB2GRAY)
            val gb3 = m(); Imgproc.GaussianBlur(gray0, gb3, Size(3.0, 3.0), 0.0)
            val edgeM = m(); Imgproc.Canny(gb3, edgeM, 60.0, 140.0)
            val edges = Img(cols, rows, bytes(edgeM))
            val gray = m(); Imgproc.GaussianBlur(gray0, gray, Size(5.0, 5.0), 1.5)

            // 2) körök (golyók + a játék szellemgyűrűje)
            val circ = m()
            Imgproc.HoughCircles(
                gray, circ, Imgproc.HOUGH_GRADIENT, 1.0, r * 1.6, 100.0, 0.25 * 2.0 * PI * r,
                (r * 0.8).toInt(), (r * 1.25).toInt()
            )
            val cs = ArrayList<Circ>()
            for (i in 0 until circ.cols()) {
                val c = circ.get(0, i)
                val x = c[0]; val y = c[1]
                if (x < tb.x || x > tb.x + tb.width || y < tb.y || y > tb.y + tb.height) continue
                cs += classify(x, y, r, rgbA, cols, rows, felt)
            }

            // 3) fehér golyó + szellemgyűrű párosítása: a kettő között végig ott a játék fehér vonala
            var bestL = Double.MAX_VALUE
            var cueC: Circ? = null
            var ringC: Circ? = null
            for (c in cs) {
                if (!c.white) continue
                for (g in cs) {
                    if (!g.empty) continue
                    val l = hypot(g.x - c.x, g.y - c.y)
                    if (l < 2.2 * r || l >= bestL) continue
                    if (cover(Vec(c.x, c.y), Vec(g.x, g.y), r, lineOk) >= 0.8) { bestL = l; cueC = c; ringC = g }
                }
            }

            var cue: Vec? = null
            var dir: Vec? = null
            var ghost: Vec? = null
            var target: Vec? = null
            var cueCircle: Circ? = null
            val cc = cueC
            val rc = ringC
            if (cc != null && rc != null) {
                cueCircle = cc
                val c0 = refine(edges, Vec(cc.x, cc.y), r, 0.2)
                val g = refine(bright, Vec(rc.x, rc.y), r, 0.28)
                cue = c0
                dir = (g - c0).norm()
                ghost = g
                // célgolyó: a gyűrűtől ~2r-re levő golyó (színtől független); ha a Hough nem találta, szkenneljük
                var tc: Circ? = null
                var bd = Double.MAX_VALUE
                for (b in cs) {
                    if (b === cc || b === rc || b.empty) continue
                    val dd = hypot(b.x - g.x, b.y - g.y)
                    if (dd < 1.6 * r || dd > 2.4 * r) continue
                    val e = abs(dd - 2 * r)
                    if (e < bd) { bd = e; tc = b }
                }
                val tcc = tc
                val start: Vec? = if (tcc != null) Vec(tcc.x, tcc.y) else findByScan(g, r, rgbA, cols, rows, felt)
                if (start != null) target = refine(edges, start, r, 0.2)
            } else {
                // nincs szellemgyűrű (pl. falnak megy a vonal): irány a fehér vonal szögszkenneléséből
                var bestRun = 0.0
                var bestDir: Vec? = null
                var bestCue: Circ? = null
                for (c in cs) {
                    if (!c.white) continue
                    val res = scanGuide(Vec(c.x, c.y), r, lineOk) ?: continue
                    if (res[2] > bestRun) { bestRun = res[2]; bestDir = Vec(res[0], res[1]); bestCue = c }
                }
                if (bestDir == null || bestCue == null) {
                    status = "nincs feher golyo/vonal: kor=${cs.size}"
                    return null
                }
                cueCircle = bestCue
                cue = refine(edges, Vec(bestCue.x, bestCue.y), r, 0.2)
                dir = bestDir
            }
            if (cue == null || dir == null) { status = "nincs feher golyo/vonal"; return null }

            val balls = ArrayList<Vec>()
            for (c in cs) {
                if (c.empty || c === cueCircle) continue
                balls += Vec(c.x / s, c.y / s)
            }
            val inv = 1.0 / s
            val ins = inset * inv
            status = if (ghost != null && target != null) "OK gyuru+celgolyo, golyok=${balls.size}"
            else if (ghost != null) "gyuru OK, celgolyo nincs"
            else "OK vonal (nincs gyuru), golyok=${balls.size}"
            return Scene(
                cue = cue * inv,
                dir = dir,
                balls = balls,
                table = Table(tb.x * inv + ins, tb.y * inv + ins, (tb.x + tb.width) * inv - ins, (tb.y + tb.height) * inv - ins),
                r = r * inv,
                ghost = if (ghost != null && target != null) ghost * inv else null,
                target = if (ghost != null && target != null) target * inv else null
            )
        } finally {
            mats.forEach { it.release() }
        }
    }

    // ---------------------------------------------------------------- segédek

    private fun medianRect(rgb: ByteArray, cols: Int, x0: Int, y0: Int, x1: Int, y1: Int): IntArray {
        val n = ((x1 - x0) / 3 + 2) * ((y1 - y0) / 3 + 2)
        val a = IntArray(n); val b = IntArray(n); val c = IntArray(n)
        var k = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val i = (y * cols + x) * 3
                a[k] = rgb[i].toInt() and 0xFF; b[k] = rgb[i + 1].toInt() and 0xFF; c[k] = rgb[i + 2].toInt() and 0xFF
                k++; x += 3
            }
            y += 3
        }
        if (k == 0) return intArrayOf(70, 150, 70)
        Arrays.sort(a, 0, k); Arrays.sort(b, 0, k); Arrays.sort(c, 0, k)
        return intArrayOf(a[k / 2], b[k / 2], c[k / 2])
    }

    /** A kör belsejének (0.55r) mediánszíne: "empty" = olyan, mint a posztó (szellemgyűrű), "white" = főleg fehér (fehér golyó). */
    private fun classify(cx: Double, cy: Double, r: Double, rgb: ByteArray, cols: Int, rows: Int, felt: IntArray): Circ {
        val rad = 0.55 * r
        val x0 = max(0, floor(cx - rad).toInt()); val x1 = min(cols - 1, ceil(cx + rad).toInt())
        val y0 = max(0, floor(cy - rad).toInt()); val y1 = min(rows - 1, ceil(cy + rad).toInt())
        val cap = (x1 - x0 + 1) * (y1 - y0 + 1)
        if (cap <= 0) return Circ(cx, cy, false, false)
        val rr = IntArray(cap); val gg = IntArray(cap); val bb = IntArray(cap)
        var n = 0
        var w = 0
        for (y in y0..y1) for (x in x0..x1) {
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy > rad * rad) continue
            val i = (y * cols + x) * 3
            val pr = rgb[i].toInt() and 0xFF; val pg = rgb[i + 1].toInt() and 0xFF; val pb = rgb[i + 2].toInt() and 0xFF
            rr[n] = pr; gg[n] = pg; bb[n] = pb
            if (min(pr, min(pg, pb)) > 190) w++
            n++
        }
        if (n == 0) return Circ(cx, cy, false, false)
        Arrays.sort(rr, 0, n); Arrays.sort(gg, 0, n); Arrays.sort(bb, 0, n)
        val empty = abs(rr[n / 2] - felt[0]) < 30 && abs(gg[n / 2] - felt[1]) < 30 && abs(bb[n / 2] - felt[2]) < 30
        return Circ(cx, cy, empty, w.toDouble() / n >= 0.65)
    }

    /** Mennyire fedi a "fehér" maszk az a->b szakaszt (a két végén kihagyunk ~1r-t). */
    private fun cover(a: Vec, b: Vec, r: Double, ok: Img): Double {
        val l = (b - a).len()
        if (l < 1e-6) return 0.0
        val u = (b - a).norm()
        var hit = 0; var tot = 0
        var t = 1.1 * r
        while (t < l - r) {
            val p = a + u * t
            tot++
            if (ok.on(p.x.roundToInt(), p.y.roundToInt())) hit++
            t += 1.0
        }
        return if (tot == 0) 1.0 else hit.toDouble() / tot
    }

    /** Legkisebb négyzetes körillesztés (Kåsa), középre tolt koordinátákkal. Visszaad: [cx, cy, sugár]. */
    private fun fitCircle(px: DoubleArray, py: DoubleArray, n: Int): DoubleArray? {
        if (n < 3) return null
        var mx = 0.0; var my = 0.0
        for (i in 0 until n) { mx += px[i]; my += py[i] }
        mx /= n; my /= n
        var suu = 0.0; var suv = 0.0; var svv = 0.0; var bu = 0.0; var bv = 0.0; var sz = 0.0
        for (i in 0 until n) {
            val u = px[i] - mx; val v = py[i] - my
            val z = u * u + v * v
            suu += u * u; suv += u * v; svv += v * v
            bu -= z * u; bv -= z * v; sz += z
        }
        val det = suu * svv - suv * suv
        if (abs(det) < 1e-9) return null
        val d = (bu * svv - bv * suv) / det
        val e = (suu * bv - suv * bu) / det
        val f = -sz / n
        return doubleArrayOf(mx - d / 2, my - e / 2, sqrt(max(d * d / 4 + e * e / 4 - f, 0.0)))
    }

    /** Pontosítás: a maszk (él / fényes) pixeleire illesztett kör -> szubpixeles középpont. Ha nincs elég pont, marad az eredeti. */
    private fun refine(mask: Img, c: Vec, r: Double, band: Double): Vec {
        var cx = c.x; var cy = c.y
        val cap = ((4 * r + 3) * (4 * r + 3)).toInt() + 16
        val px = DoubleArray(cap); val py = DoubleArray(cap); val res = DoubleArray(cap)
        for (iter in 0 until 3) {
            val x0 = max(0, (cx - 2 * r).toInt()); val x1 = min(mask.cols - 1, (cx + 2 * r).toInt())
            val y0 = max(0, (cy - 2 * r).toInt()); val y1 = min(mask.rows - 1, (cy + 2 * r).toInt())
            var n = 0
            for (y in y0..y1) for (x in x0..x1) {
                if (!mask.on(x, y)) continue
                if (abs(hypot(x - cx, y - cy) - r) < band * r && n < cap) { px[n] = x.toDouble(); py[n] = y.toDouble(); n++ }
            }
            if (n < 12) return c
            var f: DoubleArray? = null
            for (k in 0 until 3) {
                val fit = fitCircle(px, py, n) ?: break
                f = fit
                for (i in 0 until n) res[i] = abs(hypot(px[i] - fit[0], py[i] - fit[1]) - fit[2])
                val sorted = res.copyOfRange(0, n); sorted.sort()
                val thr = max(1.0, sorted[(0.7 * (n - 1)).toInt()])
                var m2 = 0
                for (i in 0 until n) if (res[i] < thr) { px[m2] = px[i]; py[m2] = py[i]; m2++ }
                if (m2 < 10) break
                n = m2
            }
            if (f == null) return c
            cx = f[0]; cy = f[1]
        }
        return if (hypot(cx - c.x, cy - c.y) < 0.5 * r) Vec(cx, cy) else c
    }

    /** Szögszkennelés: honnan indul a leghosszabb összefüggő fehér szakasz? Visszaad: [dx, dy, hossz]. */
    private fun scanGuide(c: Vec, r: Double, ok: Img): DoubleArray? {
        val t0 = 1.15 * r
        val tMax = 14.0 * r
        val steps = 1440
        val runs = DoubleArray(steps)
        var best = 0.0
        var bi = 0
        for (k in 0 until steps) {
            val a = k * 2.0 * PI / steps
            val ux = cos(a); val uy = sin(a)
            var t = t0; var last = t0; var gap = 0
            while (t < tMax) {
                val x = (c.x + ux * t).roundToInt(); val y = (c.y + uy * t).roundToInt()
                if (x < 0 || y < 0 || x >= ok.cols || y >= ok.rows) break
                if (ok.on(x, y)) { last = t; gap = 0 } else { gap++; if (gap > 3) break }
                t += 1.0
            }
            runs[k] = last - t0
            if (runs[k] > best) { best = runs[k]; bi = k }
        }
        if (best < 3.0 * r) return null
        var sx = 0.0; var sy = 0.0
        for (dk in -6..6) {
            val k = (bi + dk + steps) % steps
            if (runs[k] >= best - 2.0) { val a = k * 2.0 * PI / steps; sx += cos(a); sy += sin(a) }
        }
        val d = Vec(sx, sy).norm()
        return doubleArrayOf(d.x, d.y, best)
    }

    private fun nonFelt(rgb: ByteArray, cols: Int, rows: Int, x: Int, y: Int, felt: IntArray): Boolean {
        if (x < 0 || y < 0 || x >= cols || y >= rows) return false
        val i = (y * cols + x) * 3
        return abs((rgb[i].toInt() and 0xFF) - felt[0]) > 35 || abs((rgb[i + 1].toInt() and 0xFF) - felt[1]) > 35 ||
            abs((rgb[i + 2].toInt() and 0xFF) - felt[2]) > 35
    }

    /** Ha a Hough nem találta meg az eltalált golyót: a gyűrű körül 2r-nél keressük a "nem posztó" foltot (színtől független). */
    private fun findByScan(g: Vec, r: Double, rgb: ByteArray, cols: Int, rows: Int, felt: IntArray): Vec? {
        val steps = 720
        val sc = DoubleArray(steps)
        var best = -1.0; var bi = 0
        for (k in 0 until steps) {
            val a = k * 2.0 * PI / steps
            val px = g.x + 2 * r * cos(a); val py = g.y + 2 * r * sin(a)
            var cnt = 0
            if (nonFelt(rgb, cols, rows, px.roundToInt(), py.roundToInt(), felt)) cnt++
            for (j in 0 until 8) {
                val b = j * PI / 4
                if (nonFelt(rgb, cols, rows, (px + 0.5 * r * cos(b)).roundToInt(), (py + 0.5 * r * sin(b)).roundToInt(), felt)) cnt++
            }
            sc[k] = cnt / 9.0
            if (sc[k] > best) { best = sc[k]; bi = k }
        }
        if (best < 0.85) return null
        var sx = 0.0; var sy = 0.0
        for (dk in -15..15) {
            val k = (bi + dk + steps) % steps
            if (sc[k] >= best - 0.05) { val a = k * 2.0 * PI / steps; sx += cos(a); sy += sin(a) }
        }
        val u = Vec(sx, sy).norm()
        var e = g + u * (2 * r)
        for (it in 0 until 5) {
            var sx2 = 0.0; var sy2 = 0.0; var n = 0
            val x0 = floor(e.x - 1.05 * r).toInt(); val x1 = ceil(e.x + 1.05 * r).toInt()
            val y0 = floor(e.y - 1.05 * r).toInt(); val y1 = ceil(e.y + 1.05 * r).toInt()
            for (y in y0..y1) for (x in x0..x1) {
                if (hypot(x - e.x, y - e.y) > 1.05 * r) continue
                if (hypot(x - g.x, y - g.y) <= r + 2) continue
                if (!nonFelt(rgb, cols, rows, x, y, felt)) continue
                sx2 += x; sy2 += y; n++
            }
            if (n == 0) break
            e = Vec(sx2 / n, sy2 / n)
        }
        return e
    }
}
