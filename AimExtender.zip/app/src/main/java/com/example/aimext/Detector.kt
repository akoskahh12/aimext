package com.example.aimext

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.*

data class Vec(val x: Double, val y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun len() = hypot(x, y)
    fun norm(): Vec { val l = len(); return if (l < 1e-9) Vec(0.0, 0.0) else Vec(x / l, y / l) }
}

data class Table(val left: Double, val top: Double, val right: Double, val bottom: Double)

/** Minden koordináta teljes felbontású képernyő-pixel. */
data class Scene(val cue: Vec, val dir: Vec, val balls: List<Vec>, val table: Table, val r: Double)

object Detector {
    @Volatile var status = ""
    /** Golyósugár / képernyőszélesség. A mintaképen ~20px / 1080px. Ha nem stimmel a játékodban, ezt állítsd. */
    const val BALL_R_FRAC = 0.0185
    private const val WORK_W = 540.0

    fun detect(bmp: Bitmap): Scene? {
        val mats = ArrayList<Mat>()
        fun m() = Mat().also { mats.add(it) }
        try {
            val full = m()
            Utils.bitmapToMat(bmp, full)
            val s = WORK_W / bmp.width
            val small = m()
            Imgproc.resize(full, small, Size(), s, s, Imgproc.INTER_AREA)
            val rgb = m()
            Imgproc.cvtColor(small, rgb, Imgproc.COLOR_RGBA2RGB)
            val r = bmp.width * BALL_R_FRAC * s
            val bright = Core.mean(rgb).`val`.average().toInt()

            // 1) asztal = legnagyobb zöld folt
            val hsv = m(); Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
            val green = m(); Core.inRange(hsv, Scalar(35.0, 60.0, 60.0), Scalar(90.0, 255.0, 255.0), green)
            val gc = ArrayList<MatOfPoint>()
            Imgproc.findContours(green.clone(), gc, m(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val big = gc.maxByOrNull { Imgproc.contourArea(it) } ?: run { status = "asztal nincs (feny=$bright)"; return null }
            val tb = Imgproc.boundingRect(big)
            if (tb.width < r * 10 || tb.height < r * 10) { status = "asztal tul kicsi (feny=$bright)"; return null }

            // 2) fehér maszk (fehér golyó + fehér segédvonal)
            val white = m(); Core.inRange(rgb, Scalar(215.0, 215.0, 215.0), Scalar(255.0, 255.0, 255.0), white)

            // fehér golyó jelöltek: a vékony vonalat a "nyitás" eltünteti, a golyó marad
            val k = max(3, (r * 0.9).toInt()) or 1
            val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(k.toDouble(), k.toDouble()))
            val opened = m(); Imgproc.morphologyEx(white, opened, Imgproc.MORPH_OPEN, kernel)
            val bc = ArrayList<MatOfPoint>()
            Imgproc.findContours(opened, bc, m(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
            val a0 = PI * r * r
            val cands = bc.filter { val a = Imgproc.contourArea(it); a > 0.15 * a0 && a < 1.6 * a0 }
                .mapNotNull {
                    val mo = Imgproc.moments(it)
                    if (mo.m00 > 0) Vec(mo.m10 / mo.m00, mo.m01 / mo.m00) else null
                }

            // 3) segédvonal: az a hosszú fehér szakasz, ami valamelyik jelölt közepéből indul
            val lines = m()
            Imgproc.HoughLinesP(white, lines, 1.0, PI / 180, 30, r * 5, r * 0.8)
            var cue: Vec? = null
            var dir: Vec? = null
            var guideEnd: Vec? = null
            var bestLen = 0.0
            for (c in cands) for (i in 0 until lines.rows()) {
                val l = lines.get(i, 0)
                val p1 = Vec(l[0], l[1]); val p2 = Vec(l[2], l[3])
                val d1 = (p1 - c).len(); val d2 = (p2 - c).len()
                if (min(d1, d2) > 2.2 * r) continue
                val near = if (d1 < d2) p1 else p2
                val far = if (d1 < d2) p2 else p1
                val dn = (far - near).norm()
                val perp = abs((c - near).x * dn.y - (c - near).y * dn.x)
                if (perp > r) continue
                val len = (far - near).len()
                if (len > bestLen) { bestLen = len; cue = c; dir = dn; guideEnd = far }
            }
            if (cue == null || dir == null || guideEnd == null) {
                status = "asztal OK, feher golyo/vonal nincs: jelolt=${cands.size} vonal=${lines.rows()} feny=$bright"
                return null
            }

            // 4) golyók (HoughCircles), a szellemgyűrűt és a fehér golyót kiszűrjük
            val gray = m(); Imgproc.cvtColor(rgb, gray, Imgproc.COLOR_RGB2GRAY)
            Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 1.5)
            val circ = m()
            Imgproc.HoughCircles(
                gray, circ, Imgproc.HOUGH_GRADIENT, 1.0, r * 1.6, 100.0, 16.0,
                (r * 0.8).toInt(), (r * 1.25).toInt()
            )
            val segEnd = guideEnd + dir * (r * 1.2)
            val balls = ArrayList<Vec>()
            for (i in 0 until circ.cols()) {
                val c = circ.get(0, i)
                val p = Vec(c[0], c[1])
                if (p.x < tb.x || p.x > tb.x + tb.width || p.y < tb.y || p.y > tb.y + tb.height) continue
                if ((p - cue).len() < r) continue
                if (distToSegment(p, cue, segEnd) < 0.7 * r) continue   // szellemgyűrű
                balls += Vec(p.x / s, p.y / s)
            }

            status = "OK golyok=${balls.size} feny=$bright"
            return Scene(
                cue = Vec(cue.x / s, cue.y / s),
                dir = dir,
                balls = balls,
                table = Table(tb.x / s, tb.y / s, (tb.x + tb.width) / s, (tb.y + tb.height) / s),
                r = r / s
            )
        } finally {
            mats.forEach { it.release() }
        }
    }

    private fun distToSegment(p: Vec, a: Vec, b: Vec): Double {
        val ab = b - a
        val t = ((p - a).dot(ab) / max(ab.dot(ab), 1e-9)).coerceIn(0.0, 1.0)
        return (p - (a + ab * t)).len()
    }
}
