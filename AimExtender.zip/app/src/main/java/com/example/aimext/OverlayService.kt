package com.example.aimext

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.content.IntentCompat
import org.opencv.android.OpenCVLoader

class OverlayService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private lateinit var wm: WindowManager
    private val thread = HandlerThread("aim").apply { start() }
    private val handler = Handler(thread.looper)
    @Volatile private var running = false
    private var w = 0
    private var h = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startForegroundCompat()
        if (!OpenCVLoader.initLocal()) { Log.e(TAG, "OpenCV init failed"); stopSelf(); return START_NOT_STICKY }

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels

        // overlay
        overlay = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(overlay, lp)

        // képernyőrögzítés
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vDisplay = projection!!.createVirtualDisplay(
            "aim", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )

        running = true
        handler.post(loop)
        return START_NOT_STICKY
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                val img = reader?.acquireLatestImage()
                if (img != null) {
                    try {
                        val p = img.planes[0]
                        val rowPad = p.rowStride - p.pixelStride * w
                        val full = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
                        full.copyPixelsFromBuffer(p.buffer)
                        val bmp = if (rowPad > 0) Bitmap.createBitmap(full, 0, 0, w, h) else full
                        val scene = Detector.detect(bmp)
                        val segs = if (scene != null) Trajectory.trace(scene) else emptyList()
                        val r = scene?.r ?: 0.0
                        val st = Detector.status
                        overlay?.post { overlay?.update(segs, r, st) }
                    } finally { img.close() }
                }
            } catch (e: Exception) {
                Log.e(TAG, "frame error", e)
                overlay?.post { overlay?.update(emptyList(), 0.0, "hiba: ${e.javaClass.simpleName} ${e.message}") }
            }
            handler.postDelayed(this, 120)
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("aim", "Aim", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "aim")
            .setContentTitle("AimExtender fut")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "Leállítás", stopPi
                ).build()
            ).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        overlay?.let { runCatching { wm.removeView(it) } }
        thread.quitSafely()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "stop"
        const val TAG = "AimExt"
    }
}
