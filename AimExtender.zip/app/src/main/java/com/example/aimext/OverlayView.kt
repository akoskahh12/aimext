package com.example.aimext

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** A rárajzolás színei. A Detector ezeket retusálja ki a képből, ezért ezek legyenek szokatlanul tiszta színek. */
object Palette {
    val CUE = 0xFF00FFFF.toInt()      // cián: fehér golyó
    val TARGET = 0xFFFF00FF.toInt()   // magenta: eltalált golyó (mindig ugyanez, a golyó színétől függetlenül)
}

class OverlayView(ctx: Context) : View(ctx) {
    private var segs: List<Seg> = emptyList()
    private var r = 0.0
    private var status = "indul..."
    private val dens = ctx.resources.displayMetrics.density
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.CUE; textSize = 12f * dens }

    private fun paint(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val cue = paint(Palette.CUE)
    private val target = paint(Palette.TARGET)

    fun update(s: List<Seg>, radius: Double, st: String) { segs = s; r = radius; status = st; invalidate() }

    private val loc = IntArray(2)

    override fun onDraw(c: Canvas) {
        // Ha az ablak nem a képernyő (0,0)-jától indul (státuszsor / kamera-kivágás), kompenzálunk.
        getLocationOnScreen(loc)
        c.save()
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        // a vonalvastagság a golyóhoz igazodik (bármilyen képernyőméreten)
        val w = if (r > 0) max3(r.toFloat() * 0.18f) else 5f
        cue.strokeWidth = w; target.strokeWidth = w
        c.drawText(status, 16f * dens, 56f * dens, txt)   // csak szín (nincs háttér): a felismerő kiretusálja
        for (s in segs) {
            val p = if (s.kind == 1) target else cue
            c.drawLine(s.a.x.toFloat(), s.a.y.toFloat(), s.b.x.toFloat(), s.b.y.toFloat(), p)
            if (s.ghost) c.drawCircle(s.b.x.toFloat(), s.b.y.toFloat(), r.toFloat(), p)
        }
        c.restore()
    }

    private fun max3(v: Float) = if (v < 3f) 3f else v
}
