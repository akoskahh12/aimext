package com.example.aimext

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Átlátszó réteg. Szándékosan NEM fehér színekkel rajzol, hogy a felismerő ne a saját vonalunkat lássa. */
class OverlayView(ctx: Context) : View(ctx) {
    private var segs: List<Seg> = emptyList()
    private var r = 0.0

    private fun paint(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = 5f
    }
    private val cue = paint(0xFF00E5FF.toInt())      // fehér golyó útja
    private val target = paint(0xFFFFC107.toInt())   // eltalált golyó útja
    private val deflect = paint(0xFFFF4081.toInt())  // fehér golyó ütközés utáni útja

    fun update(s: List<Seg>, radius: Double) { segs = s; r = radius; invalidate() }

    override fun onDraw(c: Canvas) {
        for (s in segs) {
            val p = when (s.kind) { 0 -> cue; 1 -> target; else -> deflect }
            c.drawLine(s.a.x.toFloat(), s.a.y.toFloat(), s.b.x.toFloat(), s.b.y.toFloat(), p)
            if (s.ghost) c.drawCircle(s.b.x.toFloat(), s.b.y.toFloat(), r.toFloat(), p)
        }
    }
}
