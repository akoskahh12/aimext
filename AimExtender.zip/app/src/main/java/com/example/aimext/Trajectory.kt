package com.example.aimext

import kotlin.math.*

/** kind: 0 = fehér golyó útja (falról visszapattanva), 1 = eltalált golyó útja, 2 = fehér golyó az ütközés után. */
data class Seg(val a: Vec, val b: Vec, val kind: Int, val ghost: Boolean = false)

object Trajectory {
    /**
     * Csak azt rajzoljuk, amit a játék NEM rajzol: az első szakaszt (fehér golyó -> szellemgyűrű / fal) a játék már megrajzolja,
     * ráadásul ha mi is odarajzolnánk, eltakarnánk a felismerő elől.
     */
    fun trace(s: Scene): List<Seg> {
        val out = ArrayList<Seg>()
        val r = s.r
        val l = s.table.left + r
        val t = s.table.top + r
        val rr = s.table.right - r
        val b = s.table.bottom - r

        fun wallT(p: Vec, d: Vec): Double {
            var tt = Double.MAX_VALUE
            if (d.x > 1e-9) tt = min(tt, (rr - p.x) / d.x) else if (d.x < -1e-9) tt = min(tt, (l - p.x) / d.x)
            if (d.y > 1e-9) tt = min(tt, (b - p.y) / d.y) else if (d.y < -1e-9) tt = min(tt, (t - p.y) / d.y)
            return max(tt, 0.0)
        }

        /** Egyenes + visszaverődés a falakról (max `maxSeg` szakasz). */
        fun ray(p0: Vec, d0: Vec, kind: Int, maxSeg: Int) {
            var p = p0
            var d = d0
            for (k in 0 until maxSeg) {
                val tw = wallT(p, d)
                val e = p + d * tw
                out += Seg(p, e, kind)
                if (tw < 1e-3) break
                if (abs(e.x - l) < 1e-3 || abs(e.x - rr) < 1e-3) d = Vec(-d.x, d.y)
                if (abs(e.y - t) < 1e-3 || abs(e.y - b) < 1e-3) d = Vec(d.x, -d.y)
                p = e
            }
        }

        fun afterContact(contact: Vec, hit: Vec, d: Vec) {
            val n = (hit - contact).norm()
            ray(hit + n * r, n, 1, 4)                       // eltalált golyó útja
            val dc = d - n * d.dot(n)                       // fehér golyó érintő irányban megy tovább
            if (dc.len() > 0.05) {
                val dn = dc.norm()
                ray(contact + dn * r, dn, 2, 4)
            }
        }

        // 1) a játék saját szellemgyűrűje + eltalált golyó ismert: pontosan a játék fizikáját folytatjuk
        val g = s.ghost
        val tg = s.target
        if (g != null && tg != null) {
            afterContact(g, tg, s.dir)
            return out
        }

        // 2) nincs gyűrű: sugárkövetés a felismert golyókkal
        var pos = s.cue
        var d = s.dir
        for (i in 0 until 4) {
            val tw = wallT(pos, d)
            var tb = Double.MAX_VALUE
            var hit: Vec? = null
            for (ball in s.balls) {
                val f = pos - ball
                val bb = f.dot(d)
                val disc = bb * bb - (f.dot(f) - 4 * r * r)
                if (disc < 0) continue
                val tt = -bb - sqrt(disc)
                if (tt > 1e-6 && tt < tb) { tb = tt; hit = ball }
            }
            if (hit != null && tb < tw) {
                val c = pos + d * tb
                if (i > 0) out += Seg(pos, c, 0, ghost = true)
                afterContact(c, hit, d)
                return out
            }
            val e = pos + d * tw
            if (i > 0) out += Seg(pos, e, 0)
            if (abs(e.x - l) < 1e-3 || abs(e.x - rr) < 1e-3) d = Vec(-d.x, d.y)
            if (abs(e.y - t) < 1e-3 || abs(e.y - b) < 1e-3) d = Vec(d.x, -d.y)
            pos = e
        }
        return out
    }
}
