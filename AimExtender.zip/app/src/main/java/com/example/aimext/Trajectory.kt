package com.example.aimext

import kotlin.math.*

data class Seg(val a: Vec, val b: Vec, val kind: Int, val ghost: Boolean = false)

object Trajectory {
    fun trace(s: Scene): List<Seg> {
        val out = ArrayList<Seg>()
        val r = s.r
        val l = s.table.left + r
        val t = s.table.top + r
        val rr = s.table.right - r
        val b = s.table.bottom - r

        fun wallT(p: Vec, d: Vec): Double {
            var tt = Double.MAX_VALUE
            if (d.x > 1e-9) tt = min(tt, (rr - p.x) / d.x) else if (d.x < -1e-9) tt = min(tt, (l - p.x) / d.x)
            if (d.y > 1e-9) tt = min(tt, (b - p.y) / d.y) else if (d.y < -1e-9) tt = min(tt, (t - p.y) / d.y)
            return max(tt, 0.0)
        }

        var pos = s.cue
        var d = s.dir
        for (i in 0 until 4) {
            val tw = wallT(pos, d)
            var tb = Double.MAX_VALUE
            var hit: Vec? = null
            for (ball in s.balls) {
                val f = pos - ball
                val bb = f.dot(d)
                val disc = bb * bb - (f.dot(f) - 4 * r * r)
                if (disc < 0) continue
                val tt = -bb - sqrt(disc)
                if (tt > 1e-6 && tt < tb) { tb = tt; hit = ball }
            }
            if (hit != null && tb < tw) {
                val c = pos + d * tb
                out += Seg(pos, c, 0, ghost = true)
                val n = (hit - c).norm()
                // eltalált golyó útja: a falig megy, majd visszapattan (max 3 pattanás)
                var tp = hit
                var td = n
                for (k in 0 until 4) {
                    val tt = wallT(tp, td)
                    val te = tp + td * tt
                    out += Seg(tp, te, 1)
                    if (tt < 1e-3) break
                    if (abs(te.x - l) < 1e-3 || abs(te.x - rr) < 1e-3) td = Vec(-td.x, td.y)
                    if (abs(te.y - t) < 1e-3 || abs(te.y - b) < 1e-3) td = Vec(td.x, -td.y)
                    tp = te
                }
                val dc = d - n * d.dot(n)          // fehér golyó érintő irányban megy tovább
                if (dc.len() > 0.05) {
                    val dn = dc.norm()
                    out += Seg(c, c + dn * min(wallT(c, dn), s.table.right - s.table.left), 2)
                }
                return out
            }
            val e = pos + d * tw
            out += Seg(pos, e, 0)
            if (abs(e.x - l) < 1e-3 || abs(e.x - rr) < 1e-3) d = Vec(-d.x, d.y)
            if (abs(e.y - t) < 1e-3 || abs(e.y - b) < 1e-3) d = Vec(d.x, -d.y)
            pos = e
        }
        return out
    }
}
